<head>
    <title type="text">Bem Vindo</title>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="inc/estilos.css" >
    <script src="inc/script.js"></script>
    



</head>


<body>
    <h1>Bem vindo</h1>
    <link href="inc/pagina1.php">
    <hr/>
    <a href="listapessoa.php">Lista de Cadastros</a>
    

    
</body>