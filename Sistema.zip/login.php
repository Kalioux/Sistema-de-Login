<?php
 
include("conexao.inc.php");

if(isset($_POST['email']) && strlen($_POST['email']) > 0 ){
 
 if(!isset($_SESSION))
  session_start();

 $_SESSION['email'] = $conexao->escape_string($_POST['email']);
 $_SESSION['senha'] = md5(md5($_POST['senha']));

 $sql_code = "SELECT senha, id FROM pou WHERE email = '$_SESSION[email]'";
 $sql_query = $conexao->query($sql_code) or die($conexao->error);
 $dado = $sql_query->fetch_assoc();
 $total = $sql_query->num_rows;

 if($total == 0){
  $erro[] = "Este email nao pertence a nenhum usuario";
 }else{
  if($dado['senha'] == $_SESSION['senha']){
   $_SESSION['pou'] = $dado['id'];
  }
  else{
   $erro[] = "Senha Incorreta";
}
}

if(count($erro) == 0 || !isset($erro)){
 echo "<script> ; location.href = 'logada.php'; </script>"; 
}

}

?>


<html>
    <head>
    <title>Login :)</title>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="inc/estilos.css" >
    <script src="inc/script.js"></script>
    </head>
    
    <body>
        <h1>Login</h1>
        <p class=espaço></p>
        <a href="cadPessoa.html">Realize seu Cadastro</a>
        <p class=espaço></p>
        <form method="POST" action="">
        <label>Digite o seu e-mail:</label>
        <input type="email" name="email" value="" placeholder="Digite o e-mail"><br>
        <p class=espaço></p>
        <label>Digite sua senha:</label>
        <input type="password" name="senha" value="" placeholder="Digite a senha"><br>
        <p class=espaço></p>
        <label>Obs: Caso o login não aconteça verifique seu E-mail/Senha</label>
        <p class=espaço></p>
        <button type="submit">Enviar</button>
        </form>
    </body>
</html>