
<?php

    require('conexao.inc.php');

    $nome   = $_POST['nome'];
    $sobrenome  = $_POST['sobrenome'];
    $idade  = $_POST['idade'];
    $email   = $_POST['email'];
    $cpf    = $_POST['cpf'];
    $senha  = $_POST['senha'];


    $senha = md5(md5($_POST['senha']));

    $query = mysqli_query($conexao,"INSERT into pou (nome, sobrenome, idade, email, cpf, senha) values ('{$nome}','{$sobrenome}','{$idade}','{$email}','{$cpf}','{$senha}')");
     
    echo "<script>
        document.location = 'login.php';
    </script>";

         



?>