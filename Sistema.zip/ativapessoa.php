<?php

    $id = $_GET['id'];
    

    require('conexao.inc.php');

    $query = mysqli_query($conexao,"UPDATE pou set ativo = 1 where id={$id}");

if($query):
    echo "<script>
        document.location = 'listapessoa.php';
    </script>";
else:
    echo "<script>
           alert('Infelizmente não foi possível excluir. :C');
           document.location='listapessoa.php';
       </script>";
endif;

?>