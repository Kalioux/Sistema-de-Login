<?php

    $id = $_GET['id'];

    require('conexao.inc.php');

    $query = mysqli_query($conexao,"UPDATE pou set ativo= 0 where id={$id}");

    echo "<script>
        document.location = 'listapessoa.php';
    </script>";

?>
