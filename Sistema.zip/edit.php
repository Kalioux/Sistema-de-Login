<html>

<head>
    <title>Formulário de Cadastro de Pessoa</title>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="inc/estilos.css" >
    <script src="inc/script.js"></script>
</head>

<body>
    <h1>Edite seu cadastro</h1>
    <a href="listapessoa.php">Voltar</a>
    <p class=espaço></p>
    <hr/>


    <form method="POST" onsubmit="return validaform()" action="">
        <label>Nome do Cliente:</label>
        <input type="text" class="estilomkr" name="nome" id="nome" value="" placeholder="Edite seu nome"/>
        <p class=espaço></p>
        <label>Sobrenome:</label>
        <input type="text" class="estilomkr" name="sobrenome" id="sobrenome" value="" placeholder="Edite seu sobrenome" />
        <p class=espaço></p>
        <label>CPF:</label>
        <input type="number"  class="estilomkr" name="cpf" id="cpf" value="" placeholder="Edite seu CPF" />
        <p class=espaço></p>
        <label>Idade:</label>
        <input type="number" class="estilomkr" name="idade" id="idade" value="" placeholder="Edite sua idade" />
        <p class=espaço></p>
        <label>E-mail:</label>
        <input type="email" class="estilomkr" name="email" id="email" value="" placeholder="Edite seu E-mail" />
        <p class=espaço></p>
        <label>Senha:</label>
        <input type="password" class="estilomkr" name="senha" id="senha" value="" placeholder="Edite seu senha" />
        <p class=espaço></p>
       
        <button name= atualiza type="submit">Salvar</button>
        <p class=espaço></p>
        <label>Obs: Verifique se a edição ocorreu na pagina de listagem.</label> 
        <p class=espaço></p>
        <a href="listapessoa.php">Verificar</a>

    </form>


</body>

</html>
<?php
   
    require('conexao.inc.php');
    
    if(isset($_POST["atualiza"])){ 

    $id = $_GET['id'];

    $nome   = $_POST['nome'];
    $sobrenome  = $_POST['sobrenome'];
    $idade  = $_POST['idade'];
    $email   = $_POST['email'];
    $cpf    = $_POST['cpf'];
    $senha  = $_POST['senha'];
    


    $senha = md5(md5($_POST['senha']));

    $query = mysqli_query($conexao, "UPDATE pou set nome='$nome', sobrenome= '$sobrenome', idade= '$idade', email= '$email', cpf= '$cpf', senha= '$senha' where id= '$id'");

    
    }
    
?>