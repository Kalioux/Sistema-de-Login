
<?php
 $host = "localhost";
 $usuario = "root";
 $senha = "";
 $bd = "basefk";
   
 $conexao = mysqli_connect('localhost','root','','basefk');
    mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);



?>
