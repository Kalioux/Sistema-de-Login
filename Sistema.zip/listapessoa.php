<html>

<head>
    <title>Formulário de Cadastro</title>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="inc/estilos.css" >
    <script src="inc/script.js"></script>
</head>

<body>
    <h1>Listagem</h1>
    <a href='logada.php'>Voltar</a>
    <hr/>
    <p class=espaço></p>
<?php

    require('conexao.inc.php');
    
    $resultado = mysqli_query($conexao,"SELECT * from pou");



    echo '<table class="tabeladados">
        <tr>
            <th>CPF</th>
            <th>Nome</th>
            <th>Sobrenome</th>
            <th>Idade</th>
            <th>Ativar/Desativar</th>
            <th>Ações</th>
        <tr>';

    while($linha = mysqli_fetch_assoc($resultado)){

        echo "<tr>
            <th>{$linha['cpf']}</th>
            <th>{$linha['nome']}</th>
            <th>{$linha['sobrenome']}</th>
            <th>{$linha['idade']}</th>
            <th>";
            
            if($linha['ativo'] == 1){
                echo "<a href='desativapessoa.php?id={$linha['id']}'>Desativar</a>";
            }  else {
                echo "<a href='ativapessoa.php?id={$linha['id']}'>Ativar</a>";
            }


        echo "</th>
            <th> 
                <a href='edit.php?id={$linha['id']}'>Editar</a> 
                <a href='excluir.php?id={$linha['id']}'>Excluir</a>
            </th>
            <tr>";
    }

    echo '</table>';


?>

</body>
